from django.contrib import admin
from app.models import *
# Register your models here.


admin.site.register(Computer_Science_Quiz_Beginners)
admin.site.register(Computer_Science_Quiz_Intermediate)
admin.site.register(Computer_Science_Quiz_Advance)
admin.site.register(Networking_Quiz_Beginners)
admin.site.register(Networking_Quiz_Intermediate)
admin.site.register(Networking_Quiz_Advance)
admin.site.register(Linux_Quiz_Beginners)
admin.site.register(Linux_Quiz_Intermediate)
admin.site.register(Linux_Quiz_Advance)
admin.site.register(Electronic_Principal_Quiz)
admin.site.register(Correct)
admin.site.register(Stored_Answer)
admin.site.register(ajax)
